# dataset/

Three sets, 426 images committed, plus a script for the full 27,000.

`tools/feed_inbox.py` copies images from here into `satellite/inbox/`, which is how
the operator feeds the payload chain — there is no camera on the test rig.

```
python3 tools/feed_inbox.py --set tiles      --count 6    # hand-picked scenes
python3 tools/feed_inbox.py --set eurosat    --count 10   # labelled Sentinel-2 patches
python3 tools/feed_inbox.py --set sentinel2  --count 4    # full Sentinel-2 scenes
python3 tools/feed_inbox.py --set all        --count 12   # mixed
```

## The sets

| set | images | source | what it is |
| --- | --- | --- | --- |
| `tiles/` | 18 | NASA, USGS, NOAA, ESA via Wikimedia | 384x384 crops of famous scenes: Nile delta, Sahara, hurricane, city lights, glacier |
| `eurosat/` | 400 | Sentinel-2 via EuroSAT | 40 per class across 10 labelled land-use classes, 64x64 patches |
| `sentinel2/` | 8 | Sentinel-2 L2A via AWS Open Data | 1024x1024 scenes cut from 1830x1830 true-colour tiles |

`manifest.json` carries the metadata for all three: source, sensor, licence, cloud
fraction, and the original tile path for every Sentinel-2 scene.

## EuroSAT — the labelled set

The full dataset is 27,000 images across 10 classes. The repo ships a balanced
subset so the pipeline works the moment you clone it; the rest is one command:

```
python3 tools/fetch_eurosat.py --full      # 95 MB, expands to dataset/eurosat_full/
python3 tools/fetch_eurosat.py --subset 200
```

Classes: AnnualCrop, Forest, HerbaceousVegetation, Highway, Industrial, Pasture,
PermanentCrop, Residential, River, SeaLake.

This is the set that matters if the model is ever trained: it is labelled, it is
balanced, and 27,000 images is enough to fit something. The current placeholder
scorer ignores the labels, but the directory name travels through the pipeline as
the frame's tile name, so labels are already attached to every frame that passes
through.

**One thing to know:** EuroSAT patches are 64x64 and the tensor is 160x160, so the
pipeline upscales them. Upscaling smooths the image, the edge detector finds less
structure, and EuroSAT frames therefore score lower than the 384px tiles on
relevance — median 48 against 74 in the same run. That is not a bug and it is not
corrected for; it is what those pixels look like at that resolution. Mixing sets
in one queue will rank the native-resolution scenes higher.

## Sentinel-2 scenes

Fetched from the public AWS Open Data bucket `sentinel-s2-l2a`, which needs no
account and no key. Each scene is the 60 m true-colour image of one UTM tile,
cropped to the largest centred square with no nodata, screened for cloud cover and
contrast, then downscaled to 1024x1024.

The tile path and acquisition date for each are in `manifest.json`, so any scene
can be re-fetched or traced back to the original:

```
tiles/36/R/TN/2017/1/14/0     Nile delta, Egypt
tiles/20/L/KP/2017/11/30/0    Amazon, Brazil
```

To fetch more, the pattern is `s3://sentinel-s2-l2a/{tile}/R60m/TCI.jp2`. The 10 m
version of the same tile is `R10m/TCI.jp2` at about 110 MB.

## Landsat

Not included, and worth being straight about why: Landsat requires a free USGS
EarthExplorer account, and the public mirrors that used to work without one —
`landsat-pds` on S3, UC Merced — now return AccessDenied or 403.

What is here instead: the 18 hand-picked tiles include genuine Landsat 8 scenes
(the Kansas pivot irrigation, the Dutch fields, the Chilean open pit), and
Sentinel-2 is the same kind of data from the same orbit family, at the same 10 m.

If Landsat specifically is needed, scenes are free at
<https://earthexplorer.usgs.gov> once you register — search the area, pick a
Level-2 scene, and download the browse JPEG or the band files. No script is
shipped for it because the route needs your own credentials and an untested
downloader would be worse than a clear instruction.

## Using your own images

Anything OpenCV can read works: drop it straight into `satellite/inbox/`. The tile
name is taken from the filename and carried through the pipeline into the frame id.

Frames are resized to the tensor resolution (160 px by default) before scoring, so
large images cost decode time and nothing else. Small ones will look soft after the
downscale — see the EuroSAT note above.

## Credits and licences

- **tiles/** — public domain, NASA / USGS / NOAA / ESA, sourced via Wikimedia Commons
- **eurosat/** — Copernicus Sentinel data, free and open (ESA); EuroSAT packaging by
  Helber, Bischke, Dengel and Borth, 2019
- **sentinel2/** — Copernicus Sentinel data, free and open (ESA), via AWS Open Data
